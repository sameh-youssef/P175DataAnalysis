package lts.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class TextLoader {
    /**
     * Upload files and convert it to a list of strings.
     * @param fileName a String represents location of file on PC
     * @return a list of strings
     */
    public List<String> getLines(String fileName){
        List<String> lines = new ArrayList<>();
        try {
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            String line;
            while ((line = br.readLine()) != null){
                lines.add(line);
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
        return lines;
    }
}
