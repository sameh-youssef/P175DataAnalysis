/*
* JavaFX Application monitor average assigned speed for two different systems in a specific time.
* it calculates average speed for two system and number of starts in specific time
* Data is coming from file.data
 */
package lts.main;


import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;
import lts.model.CoolingUnit;
import lts.util.AverageRef;
import lts.util.NumberOfStarts;
import lts.util.TextLoader;
import lts.util.UnitRecordUtil;

import java.util.List;
import java.util.stream.Collectors;
/**
 * @Author Sameh youssef
 */
public class FXApplicaion extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        int date = 20; // required date
        int minHr= 9; // starting time
        int maxHr= 20; // End time

        TextLoader tl = new TextLoader();
        //FAHU Data
            List<String> fahuFields = tl.getLines("FAHU.data");
            List<CoolingUnit> fahuUnits = fahuFields.stream()
                    .map((line)-> UnitRecordUtil.parseUnit(line))
                    .collect(Collectors.toList());

            List<CoolingUnit> fahuStartsPerDay = fahuUnits.stream()
                    .filter((unit)-> unit.getDate() == date && (unit.getHr()>=minHr && unit.getHr()<= maxHr))
                    .collect(Collectors.toList());

            List<CoolingUnit> fahuWorking = fahuUnits.stream()
                    .filter((unit)-> (unit.getRefSpeed()>30 || unit.getStatus()>0) && unit.getDate()==date && (unit.getHr()>=minHr && unit.getHr()<= maxHr))
                    .collect(Collectors.toList());

        // Majlis Data
            List<String> majlisFields = tl.getLines("Majlis.data");
            List<CoolingUnit> majlisUnits = majlisFields.stream()
                    .map((line)-> UnitRecordUtil.parseUnit(line))
                    .collect(Collectors.toList());

            List<CoolingUnit> majlisStartsPerDay = majlisUnits.stream()
                    .filter((unit)-> unit.getDate()==date && (unit.getHr()>=minHr && unit.getHr()<= maxHr))
                    .collect(Collectors.toList());

            List<CoolingUnit> majlisWorking = majlisUnits.stream()
                    .filter((unit)-> (unit.getRefSpeed()>30 || unit.getStatus()>0) && unit.getDate()==date && (unit.getHr()>=minHr && unit.getHr()<= maxHr))
                    .collect(Collectors.toList());

        double avgMajlisRefSpeed = AverageRef.getAvg(majlisWorking);
        double avgFahuRefSpeed = AverageRef.getAvg(fahuWorking) * 3;
        NumberOfStarts ns = new NumberOfStarts();
        int    majlisStarting   = ns.getNumberOfStarts(majlisStartsPerDay);
        int    fahuStarting     = ns.getNumberOfStarts(fahuStartsPerDay);


        XYChart.Series<String,Number> series = new XYChart.Series();
        series.getData().add(new XYChart.Data<>("Majlis",avgMajlisRefSpeed));
        series.getData().add(new XYChart.Data<>("FAHU",avgFahuRefSpeed));
        series.getData().add(new XYChart.Data<>("Majlis Starts",majlisStarting));
        series.getData().add(new XYChart.Data<>("FAHU Starts",fahuStarting));

        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Kit");
        yAxis.setLabel("Average Ref Speed");

        BarChart<String, Number> barChart = new BarChart<>(xAxis,yAxis);
        barChart.getData().add(series);

        Scene scene = new Scene(barChart,600, 600);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    public static void main(String[] args) {
        launch();
    }
}
