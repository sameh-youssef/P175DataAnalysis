/*
* Calculates Average speed in a list of models
 */
package lts.util;

import lts.model.CoolingUnit;

import java.util.List;

public class AverageRef {
    /**
     * Calculates Average speed in a list of models
     * @param units List of assigned machines
     * @return double value of average speed
     */
    public static double getAvg(List<CoolingUnit> units){
        double avg = 0;
        for (CoolingUnit c : units){
            avg = avg + c.getRefSpeed();
        }
        avg = avg/(units.size());
        return avg;
    }
}
