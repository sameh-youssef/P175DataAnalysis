/*
*Assign data to Machine (CoolingUnit).
 */
package lts.util;

import lts.model.CoolingUnit;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class UnitRecordUtil {
    /**
     * Assign data to Machine (CoolingUnit).
     * @param dataString data represented in String separated with ,
     * @return a model of machine (CoolingUnit)
     */
    public static CoolingUnit parseUnit(String dataString){
        List<String> fields = new ArrayList<>(Arrays.asList(dataString.split(",")));
        try{
            double refSpeed = Double.parseDouble(fields.get(0));
            int status      = Integer.parseInt(fields.get(1));
            int date        = Integer.parseInt(fields.get(2));
            int hr          = Integer.parseInt(fields.get(3));
            CoolingUnit cl = new CoolingUnit(refSpeed,status,date,hr);

            return cl;
        }catch (Exception e){
            System.out.println(e.getMessage());
            return null;
        }
    }
}
