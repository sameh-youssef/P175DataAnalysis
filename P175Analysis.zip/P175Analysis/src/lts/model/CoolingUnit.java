/*
* Representing a single behavior of machine (Energy Consumption) with time
 */
package lts.model;

public class CoolingUnit {
    private double refSpeed; // assigned reference speed from PLC
    private int status; // is cooling?
    private int date; // date
    private int hr; // hour

    public CoolingUnit(double refSpeed, int status, int date, int hr) {
        this.refSpeed = refSpeed;
        this.status = status;
        this.date = date;
        this.hr = hr;
    }

    public CoolingUnit(double refSpeed, int status) {
        this.refSpeed = refSpeed;
        this.status = status;
    }

    public CoolingUnit(double refSpeed) {
        this.refSpeed = refSpeed;
    }

    public CoolingUnit(double refSpeed, int status, int date) {
        this.refSpeed = refSpeed;
        this.status = status;
        this.date = date;
    }

    public double getRefSpeed() {
        return refSpeed;
    }

    public int getStatus() {
        return status;
    }

    public int getDate() {
        return date;
    }

    public int getHr() {
        return hr;
    }

    @Override
    public String toString() {
        return "CoolingUnit{" +
                "refSpeed=" + refSpeed +
                ", status=" + status +
                ", date=" + date +
                ", hr=" + hr +
                '}';
    }
}