/*
 * Calclates number of starts for one system
 */
package lts.util;

import lts.model.CoolingUnit;

import java.util.List;

public class NumberOfStarts {
    /**
     * Calclates number of starts for one system
     * @param cls List of assigned machines
     * @return
     */
    public int getNumberOfStarts(List<CoolingUnit> cls){
        int n = 0;
        int updatedStatus = 0;
        for (CoolingUnit u : cls){
            if (u.getStatus()==1 && updatedStatus==0)
                n++;
            updatedStatus = u.getStatus();
        }
        return n;
    }
}
